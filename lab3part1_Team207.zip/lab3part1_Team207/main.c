/* 
 * File:  main.c
 * Author: sam w (TEAM 207)
 * Description: TODO
 * 
 */

#include <xc.h>
#include <sys/attribs.h>
#include "config.h"
#include "lcd.h"
#include "adc.h"
#include "timer.h"
#include "pwm.h"
#include "interrupt.h"

typedef enum{
     RAMPUP, RAMPDOWN, CHNGDIR, WAIT, TURN_BY1, TURN_BY2
}stateType;

stateType state = RAMPUP;

int main(void)
{
    SYSTEMConfigPerformance(10000000);
    
    initMotors();
    initLCD();
    initADC();
    
    int currVolt;
    int part1_seq = 1; //to keep track of part 1 test sequence state
    char volt [33];
    
    while(1)
    {
        /*continuously read ADC and change LCD display 
         * to show this
         */
        if(IFS0bits.AD1IF == 1){
            IFS0bits.AD1IF = 0;
            AD1CON1bits.ON = 0;
            if(currVolt != ADCBUFFER){
                currVolt = ADCBUFFER;
                sprintf(volt, "%1.3f", (currVolt/1023.0)*(3.3),10);
                clearLCD();
                printStringLCD(volt);
            }
            AD1CON1bits.ON = 1;
        }
        
        /* depending on the state, adjust the speed or direction of the motors*/
        switch(state){
            case WAIT:
                delayUs(1000000);
              
                if(part1_seq == 1){
                    state = TURN_BY1;
                    M1_ENABLE = 1;
                }
                else if(part1_seq == 2){
                    state = TURN_BY2;
                    M2_ENABLE = 1;
                }
                else{
                 part1_seq = 1;
                 state = RAMPUP;  
                 M1_ENABLE = 1;
                 M2_ENABLE = 1;
                }
                break;
                
            case RAMPUP: //Increase speed of motors linearly
                DUTYCYCLE_M1 += PWM_FREQUENCY*RAMP_RATE;
                DUTYCYCLE_M2 += PWM_FREQUENCY*RAMP_RATE;

                if (DUTYCYCLE_M1 >= PWM_FREQUENCY && DUTYCYCLE_M2 >= PWM_FREQUENCY) {
                    delayUs(100000000);
                    state = RAMPDOWN;
                }
                break;
                
            case RAMPDOWN: //Decrease speed of motors linearly
                DUTYCYCLE_M1 -= PWM_FREQUENCY*RAMP_RATE;
                DUTYCYCLE_M2 -= PWM_FREQUENCY*RAMP_RATE;

                 if (DUTYCYCLE_M1 <= PWM_FREQUENCY/2) {
                    M1_ENABLE = 0;
                    M2_ENABLE = 0;
                    
                    if(part1_seq > 2){
                      state = CHNGDIR;
                    }
                    else{
                      state = WAIT;
                    }
                }
                break;
                
            case TURN_BY1:
                part1_seq = 2;
                
                if(DUTYCYCLE_M1 < PWM_FREQUENCY){
                    DUTYCYCLE_M1 += PWM_FREQUENCY*RAMP_RATE;
                }
                else {
                    delayUs(100000000);
                    state = RAMPDOWN;
                }
                break;
                
            case TURN_BY2:
                part1_seq = 3;
                
                if(DUTYCYCLE_M2 < PWM_FREQUENCY){
                    DUTYCYCLE_M2 += PWM_FREQUENCY*RAMP_RATE;
                }
                else{
                    delayUs(100000000);
                    state = RAMPDOWN;
                }
                break;
                
            case CHNGDIR:
                changeDirection();
                state = WAIT;
                break;
                
        }
        
   
   }
   
    return 0;
}





