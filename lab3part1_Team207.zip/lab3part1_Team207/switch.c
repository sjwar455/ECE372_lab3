/*
 * File:   switch.c
 * Author: Garrett
 *
 * Created on September 19, 2015, 10:46 AM
 */
#include <xc.h>

void initSwitch(){
   
    TRISDbits.TRISD7 = 1;// Enable input for switch
    CNCONDbits.ON = 1;  // Turn on CN device
    CNENDbits.CNIED7 = 1;
    IEC1bits.CNDIE = 1;
    IFS1bits.CNAIF = 0;  //flag down
    IPC8bits.CNIP = 7; //interrupt priority
    CNPUDbits.CNPUD7 = 1; // enable pull up resistor
    
}


