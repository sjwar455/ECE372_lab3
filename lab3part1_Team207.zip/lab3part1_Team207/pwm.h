/* 
 * File:   pwm.h
 * Author: sam w (TEAM 207)
 * Description: This file declares the functions and relevant values and registers
 *              associated with the pulse width modulation (pwm) capability of the 
 *              output compare modules
 * 
 *              these output compare modules are used to control the speed of two 
 *              external motors based on the value provided by the adc module
 */

#ifndef PWM_H
#define PWM_H

/*General PWM Values*/
#define PWM_FREQUENCY 0x7FFF //for 305 Hz (w prescale 1:1) *from data sheet
#define GND 0
#define RAMP_RATE .01

/*Motor 1 registers */
#define M1_ENABLE OC4CONbits.ON
#define DUTYCYCLE_M1 OC4RS
#define M1_PIN_MAP 0b1011

#define M1_POSDIR_PIN RPD3Rbits.RPD3R 
#define M1_POSDIR_GND LATDbits.LATD3 
#define M1_NEGDIR_PIN RPE5Rbits.RPE5R
#define M1_NEGDIR_GND LATEbits.LATE5

/*Motor 2 registers*/
#define M2_ENABLE OC2CONbits.ON
#define DUTYCYCLE_M2 OC2RS
#define M2_PIN_MAP 0b1011

#define M2_POSDIR_PIN RPD1Rbits.RPD1R
#define M2_POSDIR_GND LATDbits.LATD1 
#define M2_NEGDIR_PIN RPD5Rbits.RPD5R 
#define M2_NEGDIR_GND LATDbits.LATD5

void initMotors();
void init_M1();
void init_M2();
void changeDirection();


#endif /*PWM_H*/