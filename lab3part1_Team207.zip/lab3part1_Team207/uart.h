/* 
 * File:   uart.h
 * Author: gvanhoy
 *
 * Created on September 22, 2015, 8:55 AM
 */

#ifndef UART_H
#define	UART_H

void initUART2();

#endif	/* UART_H */