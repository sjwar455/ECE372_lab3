/* 
 * File:   adc.h
 * Author: sam w (TEAM 207)
 * Date: 24 March 2016
 * Description: This file declares the functions and relevant values and registers
 *              associated with the Analog to Digital Converter module 
 * 
 */

#ifndef ADC_H
#define	ADC_H

#define ADCBUFFER ADC1BUF0


void initADC();


#endif	/* ADC_H */
