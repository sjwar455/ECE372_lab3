/*
 * File:   switch.c
 * Author: Garrett
 *
 * Created on September 19, 2015, 10:46 AM
 */
#include <xc.h>

void initSwitch(){
    
    TRISDbits.TRISD13 = 1;//set switch to input
    
    CNPUDbits.CNPUD13 = 1;//ENABLE RESISTOR
    CNCONDbits.ON = 1;//ENABLE CN INTERRUPT
    CNENDbits.CNIED13 = 1;//enable pin CN
    
    IFS1bits.CNDIF = 0;//put flag down  
    IPC8bits.CNIP = 7; //priority 
    IEC1bits.CNDIE = 1;//enable interrupt
}


