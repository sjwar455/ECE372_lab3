/* 
 * File:  main.c
 * Author: sam w (TEAM 207)
 * Description: TODO
 * 
 */

#include <xc.h>
#include <sys/attribs.h>
#include "config.h"
#include "lcd.h"
#include "adc.h"
#include "timer.h"
#include "pwm.h"
#include "interrupt.h"
#include "switch.h"

typedef enum{
     GO, STOP, CHNGDIR, WAIT, DEBOUNCE
}stateType;

volatile stateType state = GO;

int main(void)
{
    SYSTEMConfigPerformance(10000000);
    enableInterrupts();
    
    initMotors();
    initSwitch();
    initLCD();
    initADC();
    
    int currVolt;
    char volt [33];
    
    while(1)
    {
        /*continuously read ADC and change LCD display 
         * to show this 
         * 
         * TODO: ADD SPEED ADJUSTMENT BY ADC
         */
        if(IFS0bits.AD1IF == 1){
            IFS0bits.AD1IF = 0;
            AD1CON1bits.ON = 0;
            if(currVolt >  (ADCBUFFER + 3) || currVolt < (ADCBUFFER - 3)){

                currVolt = ADCBUFFER;
                sprintf(volt, "%1.3f", (currVolt/1023.0)*(3.3),10);
                clearLCD();
                printStringLCD(volt);
                adjustSpeed(currVolt);
            }
            AD1CON1bits.ON = 1;
        }
        
        /* depending on the state, adjust the speed or direction of the motors*/
        switch(state){
            case GO:
                M1_ENABLE = 1;
                M2_ENABLE = 1;
                break;
            case STOP:
                M1_ENABLE = 0;
                M2_ENABLE = 0;
                break;
            case WAIT:
                break;
            case CHNGDIR:
                changeDirection();
                state = WAIT;
                break;     
            case DEBOUNCE:
                delayUs(10000);
                break;
          
        } //END OF SWITCH-CASE
    }
   
    return 0;
}

void __ISR(_CHANGE_NOTICE_VECTOR, IPL7SRS) _CNInterrupt(void){
   IFS1bits.CNDIF = 0;
  
   PORTDbits.RD13;
    
    if(SWITCH == PRESSED){
        state = DEBOUNCE;
    }
    else if(SWITCH == RELEASED){
        if(state == GO){
            state = STOP;
        }
        else if(state == STOP){
            state = CHNGDIR;
        }
        else if(state == WAIT){ //after direction is changed, waiting for press
            state = GO;
        }
    }
}





